#include <msp430g2553.h>


//----------------------------------
#define LED             0x01
#define SPEAKER         0x02
#define RESET_BUTTON    0x04
#define PLAY_BUTTON     0x08
#define SLOW_BUTTON     0x10
#define FAST_BUTTON     0x20
#define SONG1_BUTTON    0X40
#define SONG2_BUTTON    0x80


//-------------------------------------------
#define NUM_NOTES   26

#define _R      1

#define _C4     1911
#define _C4s    1803
#define _D4     1703
#define _E4b    1607
#define _E4     1517
#define _F4     1432
#define _F4s    1351
#define _G4     1276
#define _G4s    1204
#define _A4     1136
#define _B4b    1073
#define _B4     1012
#define _C5     956
#define _C5s    902
#define _D5     851
#define _E5b    803
#define _E5     758
#define _F5     716
#define _F5s    676
#define _G5     638
#define _G5s    602
#define _A5     568
#define _B5b    536
#define _B5     506
#define _C6     478
/*
#define _C6s    451
#define _D6     426
#define _E6b    401
#define _E6     379
#define _F6     358
#define _F6s    338
#define _G6     319
#define _G6s    301
#define _A6     285
#define _B6b    268
#define _B6     253
#define _C7     239
*/
const unsigned int notes[NUM_NOTES] = {
        _R, // rest (inaudible frequency)
        _C4,_C4s,_D4,_E4b,_E4,_F4,_F4s,_G4,_G4s,_A4,_B4b,_B4, // 5th octave
        _C5,_C5s,_D5,_E5b,_E5,_F5,_F5s,_G5,_G5s,_A5,_B5b,_B5, // 6th octave
        _C6
};

// bit mask for defining the score
#define R       0x00
#define C4      0x01
#define C4s     0x02
#define D4      0x03
#define E4b     0x04
#define E4      0x05
#define F4      0x06
#define F4s     0x07
#define G4      0x08
#define G4s     0x09
#define A4      0x0A
#define B4b     0x0B
#define B4      0x0C
#define C5      0x0D
#define C5s     0x0E
#define D5      0x0F
#define E5b     0x10
#define E5      0x11
#define F5      0x12
#define F5s     0x13
#define G5      0x14
#define G5s     0x15
#define A5      0x16
#define B5b     0x17
#define B5      0x18
#define C6      0x19

#define NOTE_MASK   0x1F

//----------------------------------
#define NUM_DURATIONS   8

const unsigned char durations[NUM_DURATIONS] = {
        1,
        8,
        16,
        24,
        32,
        48,
        64,
        96
};


#define BREAK       0x00
#define SIXTEENTH   0x20
#define EIGTH       0x40
#define D_EIGTH     0x60
#define QUARTER     0x80
#define D_QUARTER   0xA0
#define HALF        0xC0
#define D_HALF      0xE0


// "Joy to the World"
//----------------------------------
#define SONG1_LENGTH    72

unsigned const char song1[SONG1_LENGTH] = {
    (QUARTER + C5),     // 1st measure
    (D_EIGTH + B4),
    (SIXTEENTH + A4),
    (D_QUARTER + G4),   // 2nd measure
    (EIGTH + F4),
    (QUARTER + E4),     // 3
    (QUARTER + D4),
    (D_QUARTER + C4),   // 4
    (EIGTH + G4),
    (D_QUARTER + A4),   // 5
    (BREAK + R),
    (EIGTH + A4),
    (D_QUARTER + B4),   // 6
    (BREAK + R),
    (EIGTH + B4),
    (D_QUARTER + C5),   // 7
    (BREAK + R),
    (EIGTH + C5),
    (BREAK + R),
    (EIGTH + C5),       // 8
    (EIGTH + B4),
    (EIGTH + A4),
    (EIGTH + G4),
    (BREAK + R),
    (D_EIGTH + G4),     // 9
    (SIXTEENTH + F4),
    (EIGTH + E4),
    (EIGTH + C5),
    (BREAK + R),
    (EIGTH + C5),       // 10
    (EIGTH + B4),
    (EIGTH + A4),
    (EIGTH + G4),
    (BREAK + R),
    (D_EIGTH + G4),     // 11
    (SIXTEENTH + F4),
    (EIGTH + E4),
    (BREAK + R),
    (EIGTH + E4),
    (BREAK + R),
    (EIGTH + E4),       // 12
    (BREAK + R),
    (EIGTH + E4),
    (BREAK + R),
    (EIGTH + E4),
    (BREAK + R),
    (SIXTEENTH + E4),
    (SIXTEENTH + F4),
    (D_QUARTER + G4),   // 13
    (SIXTEENTH + F4),
    (SIXTEENTH + E4),
    (EIGTH + D4),       // 14
    (BREAK + R),
    (EIGTH + D4),
    (BREAK + R),
    (EIGTH + D4),
    (BREAK + R),
    (SIXTEENTH + D4),
    (SIXTEENTH + E4),
    (D_QUARTER + F4),   // 15
    (SIXTEENTH + E4),
    (SIXTEENTH + D4),
    (EIGTH + E4),       // 16
    (QUARTER + C5),
    (EIGTH + A4),
    (D_EIGTH + G4),     // 17
    (SIXTEENTH + F4),
    (EIGTH + E4),
    (EIGTH + F4),
    (QUARTER + E4),     // 18
    (QUARTER + D4),
    (HALF + C4)         // 19
};

// "Super Mario Theme"
//----------------------------------
#define SONG2_LENGTH    418

unsigned const char song2[SONG2_LENGTH] = {
    (SIXTEENTH + E5),   // measure 1
    (BREAK + R),
    (SIXTEENTH + E5),
    (SIXTEENTH + R),    // 16th rest
    (SIXTEENTH + E5),
    (SIXTEENTH + R),    // 16th rest
    (SIXTEENTH + C5),
    (EIGTH + E5),
    (EIGTH + G5),       // measure 2
    (EIGTH + R),        // 8th rest
    (EIGTH + G4),
    (EIGTH + R),
    (D_EIGTH + C5),     // 3
    (SIXTEENTH + G4),
    (EIGTH + R),
    (EIGTH + E4),
    (SIXTEENTH + E4),   // 4
    (EIGTH + A4),
    (EIGTH + B4),
    (SIXTEENTH + B4b),
    (EIGTH + A4),
    (SIXTEENTH + G4),   // 5
    (EIGTH + E5),       // triplet
    (SIXTEENTH + G5),
    (EIGTH + A5),
    (SIXTEENTH + F5),
    (SIXTEENTH + G5),
    (SIXTEENTH + R),    // 6
    (EIGTH + E5),
    (SIXTEENTH + C5),
    (SIXTEENTH + D5),
    (EIGTH + B4),
    (SIXTEENTH + R),
    (D_EIGTH + C5),     // 7
    (SIXTEENTH + G4),
    (EIGTH + R),
    (EIGTH + E4),
    (SIXTEENTH + E4),   // 8
    (EIGTH + A4),
    (EIGTH + B4),
    (SIXTEENTH + B4b),
    (EIGTH + A4),
    (SIXTEENTH + G4),   // 9
    (EIGTH + E5),       // triplet
    (SIXTEENTH + G5),
    (EIGTH + A5),
    (SIXTEENTH + F5),
    (SIXTEENTH + G5),
    (SIXTEENTH + R),    // 10
    (EIGTH + E5),
    (SIXTEENTH + C5),
    (SIXTEENTH + D5),
    (EIGTH + B4),
    (SIXTEENTH + R),
    (EIGTH + R),        // 11
    (SIXTEENTH + G5),
    (SIXTEENTH + F5s),
    (SIXTEENTH + F5),
    (EIGTH + E5b),
    (SIXTEENTH + E5),
    (SIXTEENTH + R),    // 12
    (SIXTEENTH + G4s),
    (SIXTEENTH + A4),
    (SIXTEENTH + C5),
    (SIXTEENTH + R),
    (SIXTEENTH + A4),
    (SIXTEENTH + C5),
    (SIXTEENTH + D5),
    (EIGTH + R),        // 13
    (SIXTEENTH + G5),
    (SIXTEENTH + F5s),
    (SIXTEENTH + F5),
    (EIGTH + E5b),
    (SIXTEENTH + E5),
    (SIXTEENTH + R),    // 14
    (SIXTEENTH + C6),
    (SIXTEENTH + R),
    (SIXTEENTH + C6),
    (BREAK + R),
    (QUARTER + C6),
    (EIGTH + R),        // 15
    (SIXTEENTH + G5),
    (SIXTEENTH + F5s),
    (SIXTEENTH + F5),
    (EIGTH + E5b),
    (SIXTEENTH + E5),
    (SIXTEENTH + R),    // 16
    (SIXTEENTH + G4s),
    (SIXTEENTH + A4),
    (SIXTEENTH + C5),
    (SIXTEENTH + R),
    (SIXTEENTH + A4),
    (SIXTEENTH + C5),
    (SIXTEENTH + D5),
    (EIGTH + R),        // 17
    (EIGTH + E5b),
    (SIXTEENTH + R),
    (EIGTH + D5),
    (SIXTEENTH + R),
    (QUARTER + C5),     // 18
    (QUARTER + R),      // quarter rest
    // REPEAT 11 - 18
    (EIGTH + R),        // 11
    (SIXTEENTH + G5),
    (SIXTEENTH + F5s),
    (SIXTEENTH + F5),
    (EIGTH + E5b),
    (SIXTEENTH + E5),
    (SIXTEENTH + R),    // 12
    (SIXTEENTH + G4s),
    (SIXTEENTH + A4),
    (SIXTEENTH + C5),
    (SIXTEENTH + R),
    (SIXTEENTH + A4),
    (SIXTEENTH + C5),
    (SIXTEENTH + D5),
    (EIGTH + R),        // 13
    (SIXTEENTH + G5),
    (SIXTEENTH + F5s),
    (SIXTEENTH + F5),
    (EIGTH + E5b),
    (SIXTEENTH + E5),
    (SIXTEENTH + R),    // 14
    (SIXTEENTH + C6),
    (SIXTEENTH + R),
    (SIXTEENTH + C6),
    (BREAK + R),
    (QUARTER + C6),
    (EIGTH + R),        // 15
    (SIXTEENTH + G5),
    (SIXTEENTH + F5s),
    (SIXTEENTH + F5),
    (EIGTH + E5b),
    (SIXTEENTH + E5),
    (SIXTEENTH + R),    // 16
    (SIXTEENTH + G4s),
    (SIXTEENTH + A4),
    (SIXTEENTH + C5),
    (SIXTEENTH + R),
    (SIXTEENTH + A4),
    (SIXTEENTH + C5),
    (SIXTEENTH + D5),
    (EIGTH + R),        // 17
    (EIGTH + E5b),
    (SIXTEENTH + R),
    (EIGTH + D5),
    (SIXTEENTH + R),
    (QUARTER + C5),     // 18
    (QUARTER + R),      // quarter rest
    // END REPEAT
    (SIXTEENTH + C5),   // 19
    (BREAK + R),
    (EIGTH + C5),
    (BREAK + R),
    (SIXTEENTH + C5),
    (SIXTEENTH + R),
    (SIXTEENTH + C5),
    (EIGTH + D5),
    (SIXTEENTH + E5),   // 20
    (EIGTH + C5),
    (SIXTEENTH + A4),
    (QUARTER + G4),
    (SIXTEENTH + C5),   // 21
    (BREAK + R),
    (EIGTH + C5),
    (BREAK + R),
    (SIXTEENTH + C5),
    (SIXTEENTH + R),
    (SIXTEENTH + C5),
    (SIXTEENTH + D5),
    (SIXTEENTH + E5),
    (HALF + R),         // 22
    (SIXTEENTH + C5),   // 23
    (BREAK + R),
    (EIGTH + C5),
    (BREAK + R),
    (SIXTEENTH + C5),
    (SIXTEENTH + R),
    (SIXTEENTH + C5),
    (EIGTH + D5),
    (SIXTEENTH + E5),   // 24
    (EIGTH + C5),
    (SIXTEENTH + A4),
    (QUARTER + G4),
    (SIXTEENTH + E5),   // 25
    (BREAK + R),
    (SIXTEENTH + E5),
    (SIXTEENTH + R),
    (SIXTEENTH + E5),
    (SIXTEENTH + R),
    (SIXTEENTH + C5),
    (EIGTH + E5),
    (EIGTH + G5),       // 26
    (EIGTH + R),
    (EIGTH + G4),
    (EIGTH + R),
    (D_EIGTH + C5),     // 27
    (SIXTEENTH + G4),
    (EIGTH + R),
    (EIGTH + E4),
    (SIXTEENTH + E4),   // 28
    (EIGTH + A4),
    (EIGTH + B4),
    (SIXTEENTH + B4b),
    (EIGTH + A4),
    (SIXTEENTH + G4),   // 29
    (EIGTH + E5),       // triplet
    (SIXTEENTH + G5),
    (EIGTH + A5),
    (SIXTEENTH + F5),
    (SIXTEENTH + G5),
    (SIXTEENTH + R),    // 30
    (EIGTH + E5),
    (SIXTEENTH + C5),
    (SIXTEENTH + D5),
    (EIGTH + B4),
    (SIXTEENTH + R),
    (D_EIGTH + C5),     // 31
    (SIXTEENTH + G4),
    (EIGTH + R),
    (EIGTH + E4),
    (SIXTEENTH + E4),   // 32
    (EIGTH + A4),
    (EIGTH + B4),
    (SIXTEENTH + B4b),
    (EIGTH + A4),
    (SIXTEENTH + G4),   // 33
    (EIGTH + E5),       // triplet
    (SIXTEENTH + G5),
    (EIGTH + A5),
    (SIXTEENTH + F5),
    (SIXTEENTH + G5),
    (SIXTEENTH + R),    // 34
    (EIGTH + E5),
    (SIXTEENTH + C5),
    (SIXTEENTH + D5),
    (EIGTH + B4),
    (SIXTEENTH + R),
    (SIXTEENTH + E5),   // 35
    (EIGTH + C5),
    (SIXTEENTH + G4),
    (EIGTH + R),
    (EIGTH + G4s),
    (SIXTEENTH + A4),   // 36
    (EIGTH + F5),
    (BREAK + R),
    (SIXTEENTH + F5),
    (QUARTER + A4),
    (SIXTEENTH + B4),   // 37
    (EIGTH + A5),
    (BREAK + R),
    (SIXTEENTH + A5),
    (BREAK + R),
    (SIXTEENTH + A5),
    (EIGTH + G5),
    (SIXTEENTH + F5),
    (SIXTEENTH + E5),   // 38
    (EIGTH + C5),
    (SIXTEENTH + A4),
    (QUARTER + G4),
    (SIXTEENTH + E5),   // 39
    (EIGTH + C5),
    (SIXTEENTH + G4),
    (EIGTH + R),
    (EIGTH + G4s),
    (SIXTEENTH + A4),   // 40
    (EIGTH + F5),
    (BREAK + R),
    (SIXTEENTH + F5),
    (QUARTER + A4),
    (SIXTEENTH + B4),   // 41
    (EIGTH + F5),
    (BREAK + R),
    (SIXTEENTH + F5),
    (BREAK + R),
    (SIXTEENTH + F5),
    (EIGTH + E5),
    (SIXTEENTH + D5),
    (QUARTER + C5),     // 42
    (QUARTER + C4),
    // REPEAT 35-42
    (SIXTEENTH + E5),   // 35
    (EIGTH + C5),
    (SIXTEENTH + G4),
    (EIGTH + R),
    (EIGTH + G4s),
    (SIXTEENTH + A4),   // 36
    (EIGTH + F5),
    (BREAK + R),
    (SIXTEENTH + F5),
    (QUARTER + A4),
    (SIXTEENTH + B4),   // 37
    (EIGTH + A5),
    (BREAK + R),
    (SIXTEENTH + A5),
    (BREAK + R),
    (SIXTEENTH + A5),
    (EIGTH + G5),
    (SIXTEENTH + F5),
    (SIXTEENTH + E5),   // 38
    (EIGTH + C5),
    (SIXTEENTH + A4),
    (QUARTER + G4),
    (SIXTEENTH + E5),   // 39
    (EIGTH + C5),
    (SIXTEENTH + G4),
    (EIGTH + R),
    (EIGTH + G4s),
    (SIXTEENTH + A4),   // 40
    (EIGTH + F5),
    (BREAK + R),
    (SIXTEENTH + F5),
    (QUARTER + A4),
    (SIXTEENTH + B4),   // 41
    (EIGTH + F5),
    (BREAK + R),
    (SIXTEENTH + F5),
    (BREAK + R),
    (SIXTEENTH + F5),
    (EIGTH + E5),
    (SIXTEENTH + D5),
    (QUARTER + C5),     // 42
    (QUARTER + C4),
    // END REPEAT
    (SIXTEENTH + C5),   // 43
    (BREAK + R),
    (EIGTH + C5),
    (BREAK + R),
    (SIXTEENTH + C5),
    (SIXTEENTH + R),
    (SIXTEENTH + C5),
    (EIGTH + D5),
    (SIXTEENTH + E5),   // 44
    (EIGTH + C5),
    (SIXTEENTH + A4),
    (QUARTER + G4),
    (SIXTEENTH + C5),   // 45
    (BREAK + R),
    (EIGTH + C5),
    (BREAK + R),
    (SIXTEENTH + C5),
    (SIXTEENTH + R),
    (SIXTEENTH + C5),
    (SIXTEENTH + D5),
    (SIXTEENTH + E5),
    (HALF + R),         // 46
    (SIXTEENTH + C5),   // 47
    (BREAK + R),
    (EIGTH + C5),
    (BREAK + R),
    (SIXTEENTH + C5),
    (SIXTEENTH + R),
    (SIXTEENTH + C5),
    (EIGTH + D5),
    (SIXTEENTH + E5),   // 48
    (EIGTH + C5),
    (SIXTEENTH + A4),
    (QUARTER + G4),
    (SIXTEENTH + E5),   // 49
    (BREAK + R),
    (SIXTEENTH + E5),
    (SIXTEENTH + R),
    (SIXTEENTH + E5),
    (SIXTEENTH + R),
    (SIXTEENTH + C5),
    (EIGTH + E5),
    (EIGTH + G5),       // 50
    (EIGTH + R),
    (EIGTH + G4),
    (EIGTH + R),
    (SIXTEENTH + E5),   // 51
    (EIGTH + C5),
    (SIXTEENTH + G4),
    (EIGTH + R),
    (EIGTH + G4s),
    (SIXTEENTH + A4),   // 52
    (EIGTH + F5),
    (BREAK + R),
    (SIXTEENTH + F5),
    (QUARTER + A4),
    (SIXTEENTH + B4),   // 53
    (EIGTH + A5),
    (BREAK + R),
    (SIXTEENTH + A5),
    (BREAK + R),
    (SIXTEENTH + A5),
    (EIGTH + G5),
    (SIXTEENTH + F5),
    (SIXTEENTH + E5),   // 54
    (EIGTH + C5),
    (SIXTEENTH + A4),
    (QUARTER + G4),
    (SIXTEENTH + E5),   // 55
    (EIGTH + C5),
    (SIXTEENTH + G4),
    (EIGTH + R),
    (SIXTEENTH + G4s),
    (SIXTEENTH + A4),   // 56
    (EIGTH + F5),
    (BREAK + R),
    (SIXTEENTH + F5),
    (QUARTER + A4),
    (SIXTEENTH + B4),   // 57
    (EIGTH + F5),
    (BREAK + R),
    (SIXTEENTH + F5),
    (BREAK + R),
    (SIXTEENTH + F5),
    (EIGTH + E5),
    (SIXTEENTH + D5),
    (QUARTER + C5),     // 58
    (QUARTER + C4),
    (D_EIGTH + C5),     // 59
    (D_EIGTH + G4),
    (EIGTH + E4),
    (SIXTEENTH + A4),   // 60
    (EIGTH + B4),
    (SIXTEENTH + A4),
    (SIXTEENTH + G4s),
    (EIGTH + B4b),
    (SIXTEENTH + A4),
    (HALF + G4)         // 61
};


//----------------------------------
#define DEFAULT_TEMPO   2.25
#define FLASH_INTERVAL  30

unsigned char sys_mod = 2;
unsigned int curr_song_len = SONG1_LENGTH;
const unsigned char *curr_song = song1;
unsigned int duration_counter = 0;
unsigned int score_counter = 0;
unsigned char flash_counter = 0;
float tempo = DEFAULT_TEMPO;
unsigned char isbreak = 0;


//----------------------------------
void init_timerA(void);
void init_WDT(void);
void init_P1(void);
void toggle_pause(void);
void restart_song(void);
void increase_tempo(void);
void decrease_tempo(void);
void select_song1(void);
void select_song2(void);

// main
//----------------------------------
void main() {
    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;

    init_P1();
    init_WDT();
    init_timerA();
    restart_song();

    _bis_SR_register(GIE+LPM0_bits);
}


//----------------------------------

void init_timerA(void) {

    TA0CTL |= TACLR;
    TA0CTL = (TASSEL_2 +
              ID_0 +
              MC_1);

    TA0CCTL0=0;
}

void init_WDT(void) {

      WDTCTL =  (WDTPW +
                 WDTTMSEL +
                 WDTCNTCL +
                 0 +
                 1);

    IE1 |= WDTIE;
}

void init_P1(void) {

    P1DIR |= LED;
    P1OUT |= LED;

    P1SEL |= SPEAKER;
    P1DIR |= SPEAKER;


    P1OUT |= RESET_BUTTON;
    P1REN |= RESET_BUTTON;
    P1IES |= RESET_BUTTON;
    P1IFG &= ~RESET_BUTTON;
    P1IE  |= RESET_BUTTON;

    P1OUT |= PLAY_BUTTON;
    P1REN |= PLAY_BUTTON;
    P1IES |= PLAY_BUTTON;
    P1IFG &= ~PLAY_BUTTON;
    P1IE  |= PLAY_BUTTON;

    P1OUT |= SLOW_BUTTON;
    P1REN |= SLOW_BUTTON;
    P1IES |= SLOW_BUTTON;
    P1IFG &= ~SLOW_BUTTON;
    P1IE  |= SLOW_BUTTON;

    P1OUT |= FAST_BUTTON;
    P1REN |= FAST_BUTTON;
    P1IES |= FAST_BUTTON;
    P1IFG &= ~FAST_BUTTON;
    P1IE  |= FAST_BUTTON;

    P1OUT |= SONG1_BUTTON;
    P1REN |= SONG1_BUTTON;
    P1IES |= SONG1_BUTTON;
    P1IFG &= ~SONG1_BUTTON;
    P1IE  |= SONG1_BUTTON;

    P1OUT |= SONG2_BUTTON;
    P1REN |= SONG2_BUTTON;
    P1IES |= SONG2_BUTTON;
    P1IFG &= ~SONG2_BUTTON;
    P1IE  |= SONG2_BUTTON;
}

void toggle_pause(void) {

    if (sys_mod != 3) {

        TACCTL0 ^= OUTMOD_4;
        sys_mod = !sys_mod;

        if (!sys_mod) {
            P1OUT &= ~LED;
        }
    }
}

void decrease_tempo(void) {
    if (tempo < 10.0) {
        tempo += 0.125;
    }
}

void increase_tempo(void) {
    if(tempo > 0.125) {
        tempo -= 0.125;
    }
}

void restart_song(void) {
    TA0CTL |= TACLR;
    TACCTL0 &= ~OUTMOD_4;
    duration_counter = 0;
    score_counter = 0;
    tempo = DEFAULT_TEMPO;
    isbreak = 0;
    sys_mod = 2;
    TA0CCR0 = notes[(curr_song[0] & NOTE_MASK)]-1;
    P1OUT |= LED;
}

void select_song1(void) {
    sys_mod = 2;
    curr_song = song1;
    curr_song_len = SONG1_LENGTH;
    restart_song();
}

void select_song2(void) {
    sys_mod = 2;
    curr_song = song2;
    curr_song_len = SONG2_LENGTH;
    restart_song();
}


interrupt void button_handler(void) {

    if (P1IFG & RESET_BUTTON) {
        P1IFG &= ~RESET_BUTTON;
        restart_song();
    }
    else if (P1IFG & PLAY_BUTTON) {
        P1IFG &= ~PLAY_BUTTON;
        toggle_pause();
    }
    else if (P1IFG & SLOW_BUTTON) {
        P1IFG &= ~SLOW_BUTTON;
        decrease_tempo();
    }
    else if (P1IFG & FAST_BUTTON) {
        P1IFG &= ~FAST_BUTTON;
        increase_tempo();
    }
    else if (P1IFG & SONG1_BUTTON) {
        P1IFG &= ~SONG1_BUTTON;
        select_song1();
    }
    else if (P1IFG & SONG2_BUTTON) {
        P1IFG &= ~SONG2_BUTTON;
        select_song2();
    }
}

interrupt void WDT_interval_handler(void) {

    if (sys_mod == 0) {

        if (score_counter < curr_song_len) {

            if (!isbreak) {
                if (duration_counter >= (durations[(curr_song[score_counter] >> 5)]) * tempo) {
                    duration_counter = 0;
                    score_counter++;

                    TA0CCR0 = notes[(curr_song[score_counter] & NOTE_MASK)];

                    if (durations[(curr_song[score_counter] >> 5)] == 1) {
                        isbreak = 1;
                    }
                    else {
                        isbreak = 0;
                    }

                }
                else {
                    duration_counter++;
                }
            }
            else {
                duration_counter = 0;
                score_counter++;
                TA0CCR0 = notes[(curr_song[score_counter] & NOTE_MASK)];
                isbreak = 0;
            }

        }
        else {
            sys_mod = 3;
            TACCTL0 &= ~OUTMOD_4;
            P1OUT |= LED;
        }
    }
    else if (sys_mod == 1) {

        if (flash_counter == FLASH_INTERVAL) {
            flash_counter = 0;
            P1OUT ^= LED;
        }
        else {
            flash_counter++;
        }
    }
}



//----------------------------------
ISR_VECTOR(button_handler,".int02")
ISR_VECTOR(WDT_interval_handler,".int10")
